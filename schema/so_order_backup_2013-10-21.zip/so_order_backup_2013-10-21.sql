#
# TABLE STRUCTURE FOR: default_so_order
#

DROP TABLE IF EXISTS `default_so_order`;

CREATE TABLE `default_so_order` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `created` datetime NOT NULL,
  `updated` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `ordering_count` int(11) DEFAULT NULL,
  `status` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'pending',
  `alamat_kirim` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `harga` int(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `default_so_order` (`id`, `created`, `updated`, `created_by`, `ordering_count`, `status`, `alamat_kirim`, `user_id`, `harga`) VALUES ('1', '2013-10-01 12:09:06', '2013-10-08 09:02:20', '1', '1', 'sent', 'bandung', '1', '5000');
INSERT INTO `default_so_order` (`id`, `created`, `updated`, `created_by`, `ordering_count`, `status`, `alamat_kirim`, `user_id`, `harga`) VALUES ('2', '2013-10-03 10:51:27', NULL, '1', '2', 'paid', 'padalarang', '1', '700000');
INSERT INTO `default_so_order` (`id`, `created`, `updated`, `created_by`, `ordering_count`, `status`, `alamat_kirim`, `user_id`, `harga`) VALUES ('3', '2013-10-03 10:53:25', '2013-10-09 13:10:06', '1', '3', 'paid', 'Tanggerang', '1', '7649');
INSERT INTO `default_so_order` (`id`, `created`, `updated`, `created_by`, `ordering_count`, `status`, `alamat_kirim`, `user_id`, `harga`) VALUES ('4', '2013-10-08 09:55:13', '2013-10-09 13:09:48', '1', '4', 'paid', 'padalarang', '1', '9000000');
INSERT INTO `default_so_order` (`id`, `created`, `updated`, `created_by`, `ordering_count`, `status`, `alamat_kirim`, `user_id`, `harga`) VALUES ('6', '2013-10-10 11:23:43', '2013-10-11 08:58:07', '1', '5', 'paid', 'jhgi', '1', '876909');


